#!/usr/bin/env python3
"""
LlewOS Development Tools - Made By Llewxam
Comprehensive toolset for LlewOS development, debugging, and deployment
"""

import os
import sys
import subprocess
import argparse
import time
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Made By Llewxam - LlewOS Development Tools

class Colors:
    """ANSI color codes for terminal output"""
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    PURPLE = '\033[0;35m'
    CYAN = '\033[0;36m'
    WHITE = '\033[1;37m'
    BOLD = '\033[1m'
    NC = '\033[0m'  # No Color

class Logger:
    """Enhanced logging for development tools"""
    
    @staticmethod
    def info(message: str):
        print(f"{Colors.BLUE}[INFO]{Colors.NC} {message}")
    
    @staticmethod
    def success(message: str):
        print(f"{Colors.GREEN}[SUCCESS]{Colors.NC} {message}")
    
    @staticmethod
    def warning(message: str):
        print(f"{Colors.YELLOW}[WARNING]{Colors.NC} {message}")
    
    @staticmethod
    def error(message: str):
        print(f"{Colors.RED}[ERROR]{Colors.NC} {message}")
    
    @staticmethod
    def debug(message: str):
        print(f"{Colors.PURPLE}[DEBUG]{Colors.NC} {message}")

class SystemChecker:
    """Check system requirements and dependencies"""
    
    def __init__(self):
        self.required_tools = {
            'gcc': 'GNU Compiler Collection',
            'nasm': 'Netwide Assembler',
            'ld': 'GNU Linker',
            'make': 'GNU Make',
            'qemu-system-i386': 'QEMU x86 Emulator',
            'grub-mkrescue': 'GRUB Rescue Image Creator (optional)'
        }
    
    def check_dependencies(self) -> bool:
        """Check if all required dependencies are installed"""
        Logger.info("Checking system dependencies...")
        
        all_good = True
        for tool, description in self.required_tools.items():
            if self.check_tool(tool):
                Logger.success(f"✓ {tool}: {description}")
            else:
                Logger.error(f"✗ {tool}: {description} - NOT FOUND")
                all_good = False
        
        return all_good
    
    def check_tool(self, tool: str) -> bool:
        """Check if a specific tool is available"""
        try:
            subprocess.run([tool, '--version'], 
                         stdout=subprocess.DEVNULL, 
                         stderr=subprocess.DEVNULL, 
                         check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False
    
    def install_dependencies(self):
        """Attempt to install dependencies based on the system"""
        Logger.info("Attempting to install dependencies...")
        
        # Detect package manager
        if self.check_tool('apt-get'):
            self.install_debian_deps()
        elif self.check_tool('yum'):
            self.install_redhat_deps()
        elif self.check_tool('pacman'):
            self.install_arch_deps()
        else:
            Logger.warning("Unknown package manager. Please install dependencies manually:")
            for tool, desc in self.required_tools.items():
                Logger.info(f"  - {tool}: {desc}")
    
    def install_debian_deps(self):
        """Install dependencies on Debian/Ubuntu systems"""
        packages = [
            'build-essential', 'nasm', 'qemu-system-x86',
            'grub-pc-bin', 'grub-common', 'xorriso', 'mtools'
        ]
        
        cmd = ['sudo', 'apt-get', 'update', '&&', 'sudo', 'apt-get', 'install', '-y'] + packages
        subprocess.run(' '.join(cmd), shell=True)
    
    def install_redhat_deps(self):
        """Install dependencies on RedHat/CentOS/Fedora systems"""
        packages = ['gcc', 'nasm', 'qemu-system-x86', 'grub2-tools', 'xorriso']
        
        cmd = ['sudo', 'yum', 'install', '-y'] + packages
        subprocess.run(cmd)
    
    def install_arch_deps(self):
        """Install dependencies on Arch Linux systems"""
        packages = ['base-devel', 'nasm', 'qemu', 'grub', 'xorriso']
        
        cmd = ['sudo', 'pacman', '-S', '--noconfirm'] + packages
        subprocess.run(cmd)

class BuildManager:
    """Manage LlewOS build process"""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.build_dir = project_root / 'build'
        self.kernel_bin = self.build_dir / 'kernel.bin'
        self.iso_file = self.build_dir / 'llewos.iso'
    
    def clean_build(self):
        """Clean all build artifacts"""
        Logger.info("Cleaning build directory...")
        
        if self.build_dir.exists():
            import shutil
            shutil.rmtree(self.build_dir)
            Logger.success("Build directory cleaned")
        
        # Remove object files
        for obj_file in self.project_root.rglob('*.o'):
            obj_file.unlink()
            Logger.debug(f"Removed {obj_file}")
    
    def build_kernel(self) -> bool:
        """Build the LlewOS kernel"""
        Logger.info("Building LlewOS kernel...")
        
        try:
            result = subprocess.run(['make', 'kernel'], 
                                  cwd=self.project_root,
                                  capture_output=True, 
                                  text=True)
            
            if result.returncode == 0:
                Logger.success("Kernel built successfully")
                return True
            else:
                Logger.error(f"Kernel build failed: {result.stderr}")
                return False
        
        except Exception as e:
            Logger.error(f"Build error: {e}")
            return False
    
    def build_iso(self) -> bool:
        """Build bootable ISO image"""
        Logger.info("Building bootable ISO image...")
        
        try:
            result = subprocess.run(['make', 'all'], 
                                  cwd=self.project_root,
                                  capture_output=True, 
                                  text=True)
            
            if result.returncode == 0:
                Logger.success(f"ISO image created: {self.iso_file}")
                return True
            else:
                Logger.error(f"ISO build failed: {result.stderr}")
                return False
        
        except Exception as e:
            Logger.error(f"ISO build error: {e}")
            return False
    
    def get_build_info(self) -> Dict:
        """Get information about the current build"""
        info = {
            'kernel_exists': self.kernel_bin.exists(),
            'iso_exists': self.iso_file.exists(),
            'build_dir_exists': self.build_dir.exists(),
            'kernel_size': self.kernel_bin.stat().st_size if self.kernel_bin.exists() else 0,
            'iso_size': self.iso_file.stat().st_size if self.iso_file.exists() else 0
        }
        
        return info

class QEMUManager:
    """Manage QEMU emulation for testing LlewOS"""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.iso_file = project_root / 'build' / 'llewos.iso'
        self.qemu_cmd = self.find_qemu()
    
    def find_qemu(self) -> Optional[str]:
        """Find available QEMU executable"""
        qemu_variants = ['qemu-system-i386', 'qemu-system-x86_64']
        
        for variant in qemu_variants:
            try:
                subprocess.run([variant, '--version'], 
                             stdout=subprocess.DEVNULL, 
                             stderr=subprocess.DEVNULL, 
                             check=True)
                return variant
            except (subprocess.CalledProcessError, FileNotFoundError):
                continue
        
        return None
    
    def run_normal(self, memory: int = 64):
        """Run LlewOS in normal mode"""
        if not self.qemu_cmd:
            Logger.error("QEMU not found. Please install qemu-system-i386")
            return False
        
        if not self.iso_file.exists():
            Logger.error(f"ISO file not found: {self.iso_file}")
            return False
        
        Logger.info(f"Starting LlewOS in QEMU ({memory}MB RAM)...")
        Logger.info("Press Ctrl+Alt+G to release mouse, Ctrl+Alt+2 for monitor")
        
        cmd = [
            self.qemu_cmd,
            '-cdrom', str(self.iso_file),
            '-m', f'{memory}M',
            '-no-reboot',
            '-no-shutdown'
        ]
        
        try:
            subprocess.run(cmd)
            return True
        except KeyboardInterrupt:
            Logger.info("QEMU session terminated by user")
            return True
        except Exception as e:
            Logger.error(f"QEMU error: {e}")
            return False
    
    def run_debug(self, memory: int = 64, gdb_port: int = 1234):
        """Run LlewOS with GDB debugging enabled"""
        if not self.qemu_cmd:
            Logger.error("QEMU not found. Please install qemu-system-i386")
            return False
        
        Logger.info(f"Starting LlewOS with GDB debugging on port {gdb_port}...")
        Logger.info(f"Connect GDB with: target remote localhost:{gdb_port}")
        
        cmd = [
            self.qemu_cmd,
            '-cdrom', str(self.iso_file),
            '-m', f'{memory}M',
            '-s',  # GDB server on port 1234
            '-S',  # Freeze CPU at startup
            '-no-reboot',
            '-no-shutdown'
        ]
        
        try:
            subprocess.run(cmd)
            return True
        except KeyboardInterrupt:
            Logger.info("Debug session terminated by user")
            return True
        except Exception as e:
            Logger.error(f"Debug session error: {e}")
            return False
    
    def run_monitor(self, memory: int = 64):
        """Run LlewOS with QEMU monitor"""
        if not self.qemu_cmd:
            Logger.error("QEMU not found. Please install qemu-system-i386")
            return False
        
        Logger.info("Starting LlewOS with QEMU monitor...")
        Logger.info("QEMU monitor commands available in console")
        
        cmd = [
            self.qemu_cmd,
            '-cdrom', str(self.iso_file),
            '-m', f'{memory}M',
            '-monitor', 'stdio',
            '-no-reboot',
            '-no-shutdown'
        ]
        
        try:
            subprocess.run(cmd)
            return True
        except KeyboardInterrupt:
            Logger.info("Monitor session terminated by user")
            return True
        except Exception as e:
            Logger.error(f"Monitor session error: {e}")
            return False

class DiskImageManager:
    """Manage disk image creation and manipulation"""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.build_dir = project_root / 'build'
    
    def create_floppy_image(self, size_kb: int = 1440) -> bool:
        """Create a floppy disk image"""
        Logger.info(f"Creating floppy disk image ({size_kb}KB)...")
        
        img_file = self.build_dir / 'llewos_floppy.img'
        
        try:
            # Create empty image
            with open(img_file, 'wb') as f:
                f.write(b'\x00' * (size_kb * 1024))
            
            Logger.success(f"Floppy image created: {img_file}")
            return True
        
        except Exception as e:
            Logger.error(f"Failed to create floppy image: {e}")
            return False
    
    def create_hdd_image(self, size_mb: int = 10) -> bool:
        """Create a hard disk image"""
        Logger.info(f"Creating hard disk image ({size_mb}MB)...")
        
        img_file = self.build_dir / 'llewos_hdd.img'
        
        try:
            subprocess.run([
                'dd', 'if=/dev/zero', f'of={img_file}',
                f'bs=1M', f'count={size_mb}'
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            Logger.success(f"HDD image created: {img_file}")
            return True
        
        except subprocess.CalledProcessError as e:
            Logger.error(f"Failed to create HDD image: {e}")
            return False
        except Exception as e:
            Logger.error(f"HDD image creation error: {e}")
            return False

class ProjectManager:
    """Manage LlewOS project structure and metadata"""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.config_file = project_root / 'llewos_config.json'
    
    def create_project_structure(self):
        """Create the complete LlewOS project structure"""
        Logger.info("Creating LlewOS project structure...")
        
        directories = [
            'kernel/core',
            'kernel/arch/x86_64',
            'kernel/drivers',
            'kernel/fs',
            'kernel/include',
            'bootloader',
            'userspace/shell',
            'userspace/init',
            'userspace/utils',
            'userspace/libc',
            'drivers/network',
            'drivers/storage',
            'drivers/input',
            'tools',
            'docs',
            'build'
        ]
        
        for directory in directories:
            dir_path = self.project_root / directory
            dir_path.mkdir(parents=True, exist_ok=True)
            Logger.debug(f"Created directory: {directory}")
        
        Logger.success("Project structure created")
    
    def save_config(self, config: Dict):
        """Save project configuration"""
        with open(self.config_file, 'w') as f:
            json.dump(config, f, indent=2)
    
    def load_config(self) -> Dict:
        """Load project configuration"""
        if self.config_file.exists():
            with open(self.config_file, 'r') as f:
                return json.load(f)
        return {}
    
    def get_project_info(self) -> Dict:
        """Get comprehensive project information"""
        info = {
            'name': 'LlewOS',
            'version': '1.0',
            'author': 'Llewxam',
            'description': 'Minimal Operating System',
            'architecture': 'x86',
            'kernel_type': 'Monolithic',
            'created_by': 'Made By Llewxam'
        }
        
        # Add file counts
        info['file_counts'] = {
            'cpp_files': len(list(self.project_root.rglob('*.cpp'))),
            'c_files': len(list(self.project_root.rglob('*.c'))),
            'asm_files': len(list(self.project_root.rglob('*.asm'))),
            'header_files': len(list(self.project_root.rglob('*.h'))),
            'total_files': len(list(self.project_root.rglob('*.*')))
        }
        
        return info

class LlewOSTools:
    """Main LlewOS development tools interface"""
    
    def __init__(self):
        self.project_root = Path.cwd()
        self.system_checker = SystemChecker()
        self.build_manager = BuildManager(self.project_root)
        self.qemu_manager = QEMUManager(self.project_root)
        self.disk_manager = DiskImageManager(self.project_root)
        self.project_manager = ProjectManager(self.project_root)
    
    def show_banner(self):
        """Display the LlewOS tools banner"""
        print(f"{Colors.PURPLE}╔══════════════════════════════════════════════════════════════╗{Colors.NC}")
        print(f"{Colors.PURPLE}║                    LlewOS Development Tools                  ║{Colors.NC}")
        print(f"{Colors.PURPLE}║                      Made By Llewxam                         ║{Colors.NC}")
        print(f"{Colors.PURPLE}╚══════════════════════════════════════════════════════════════╝{Colors.NC}")
        print()
    
    def cmd_check(self, args):
        """Check system dependencies"""
        self.show_banner()
        
        if self.system_checker.check_dependencies():
            Logger.success("All dependencies are satisfied!")
            return True
        else:
            Logger.error("Some dependencies are missing")
            
            if args.install:
                self.system_checker.install_dependencies()
            else:
                Logger.info("Use --install to attempt automatic installation")
            return False
    
    def cmd_build(self, args):
        """Build LlewOS components"""
        self.show_banner()
        
        if args.clean:
            self.build_manager.clean_build()
        
        if args.kernel_only:
            return self.build_manager.build_kernel()
        else:
            return self.build_manager.build_iso()
    
    def cmd_run(self, args):
        """Run LlewOS in QEMU"""
        self.show_banner()
        
        # Build if needed
        if not self.qemu_manager.iso_file.exists():
            Logger.info("ISO not found, building first...")
            if not self.build_manager.build_iso():
                return False
        
        if args.debug:
            return self.qemu_manager.run_debug(args.memory, args.gdb_port)
        elif args.monitor:
            return self.qemu_manager.run_monitor(args.memory)
        else:
            return self.qemu_manager.run_normal(args.memory)
    
    def cmd_disk(self, args):
        """Manage disk images"""
        self.show_banner()
        
        if args.type == 'floppy':
            return self.disk_manager.create_floppy_image(args.size)
        elif args.type == 'hdd':
            return self.disk_manager.create_hdd_image(args.size)
    
    def cmd_info(self, args):
        """Show project information"""
        self.show_banner()
        
        # Project info
        project_info = self.project_manager.get_project_info()
        
        print(f"{Colors.CYAN}Project Information:{Colors.NC}")
        print(f"  Name:         {project_info['name']}")
        print(f"  Version:      {project_info['version']}")
        print(f"  Author:       {project_info['author']}")
        print(f"  Description:  {project_info['description']}")
        print(f"  Architecture: {project_info['architecture']}")
        print(f"  Kernel Type:  {project_info['kernel_type']}")
        print()
        
        # File statistics
        counts = project_info['file_counts']
        print(f"{Colors.CYAN}File Statistics:{Colors.NC}")
        print(f"  C++ Files:    {counts['cpp_files']}")
        print(f"  C Files:      {counts['c_files']}")
        print(f"  ASM Files:    {counts['asm_files']}")
        print(f"  Header Files: {counts['header_files']}")
        print(f"  Total Files:  {counts['total_files']}")
        print()
        
        # Build info
        build_info = self.build_manager.get_build_info()
        print(f"{Colors.CYAN}Build Status:{Colors.NC}")
        print(f"  Kernel Built: {'✓' if build_info['kernel_exists'] else '✗'}")
        print(f"  ISO Built:    {'✓' if build_info['iso_exists'] else '✗'}")
        
        if build_info['kernel_exists']:
            print(f"  Kernel Size:  {build_info['kernel_size']} bytes")
        if build_info['iso_exists']:
            print(f"  ISO Size:     {build_info['iso_size']} bytes")
        
        print()
        print(f"{Colors.GREEN}Made By Llewxam - LlewOS Development Tools{Colors.NC}")

def main():
    """Main entry point for LlewOS tools"""
    parser = argparse.ArgumentParser(
        description='LlewOS Development Tools - Made By Llewxam',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 llewos_tools.py check --install    # Check and install dependencies
  python3 llewos_tools.py build              # Build complete LlewOS
  python3 llewos_tools.py build --clean      # Clean build
  python3 llewos_tools.py run                # Run in QEMU
  python3 llewos_tools.py run --debug        # Run with GDB debugging
  python3 llewos_tools.py disk floppy        # Create floppy disk image
  python3 llewos_tools.py info               # Show project information
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Check command
    check_parser = subparsers.add_parser('check', help='Check system dependencies')
    check_parser.add_argument('--install', action='store_true', 
                             help='Attempt to install missing dependencies')
    
    # Build command
    build_parser = subparsers.add_parser('build', help='Build LlewOS')
    build_parser.add_argument('--clean', action='store_true', 
                             help='Clean build directory first')
    build_parser.add_argument('--kernel-only', action='store_true',
                             help='Build only the kernel')
    
    # Run command
    run_parser = subparsers.add_parser('run', help='Run LlewOS in QEMU')
    run_parser.add_argument('--debug', action='store_true',
                           help='Run with GDB debugging')
    run_parser.add_argument('--monitor', action='store_true',
                           help='Run with QEMU monitor')
    run_parser.add_argument('--memory', type=int, default=64,
                           help='Memory size in MB (default: 64)')
    run_parser.add_argument('--gdb-port', type=int, default=1234,
                           help='GDB server port (default: 1234)')
    
    # Disk command
    disk_parser = subparsers.add_parser('disk', help='Create disk images')
    disk_parser.add_argument('type', choices=['floppy', 'hdd'],
                            help='Type of disk image to create')
    disk_parser.add_argument('--size', type=int,
                            help='Size (KB for floppy, MB for HDD)')
    
    # Info command
    info_parser = subparsers.add_parser('info', help='Show project information')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    # Set default sizes
    if args.command == 'disk' and not args.size:
        args.size = 1440 if args.type == 'floppy' else 10
    
    tools = LlewOSTools()
    
    try:
        if args.command == 'check':
            success = tools.cmd_check(args)
        elif args.command == 'build':
            success = tools.cmd_build(args)
        elif args.command == 'run':
            success = tools.cmd_run(args)
        elif args.command == 'disk':
            success = tools.cmd_disk(args)
        elif args.command == 'info':
            success = tools.cmd_info(args)
        else:
            Logger.error(f"Unknown command: {args.command}")
            return 1
        
        return 0 if success else 1
    
    except KeyboardInterrupt:
        Logger.info("Operation cancelled by user")
        return 1
    except Exception as e:
        Logger.error(f"Unexpected error: {e}")
        return 1

if __name__ == '__main__':
    exit(main())

# Made By Llewxam - LlewOS Development Tools Complete

