/*
 * LlewOS Kernel - Made By Llewxam
 * Main kernel entry point and core functionality
 */

#include <stddef.h>
#include <stdint.h>

// Made By Llewxam - LlewOS Kernel Core

// Forward declarations
extern "C" void kernel_main(uint32_t magic, uint32_t addr);

// VGA text mode constants
static const size_t VGA_WIDTH = 80;
static const size_t VGA_HEIGHT = 25;
static uint16_t* const VGA_MEMORY = (uint16_t*) 0xB8000;

// VGA color constants
enum vga_color {
    VGA_COLOR_BLACK = 0,
    VGA_COLOR_BLUE = 1,
    VGA_COLOR_GREEN = 2,
    VGA_COLOR_CYAN = 3,
    VGA_COLOR_RED = 4,
    VGA_COLOR_MAGENTA = 5,
    VGA_COLOR_BROWN = 6,
    VGA_COLOR_LIGHT_GREY = 7,
    VGA_COLOR_DARK_GREY = 8,
    VGA_COLOR_LIGHT_BLUE = 9,
    VGA_COLOR_LIGHT_GREEN = 10,
    VGA_COLOR_LIGHT_CYAN = 11,
    VGA_COLOR_LIGHT_RED = 12,
    VGA_COLOR_LIGHT_MAGENTA = 13,
    VGA_COLOR_LIGHT_BROWN = 14,
    VGA_COLOR_WHITE = 15,
};

// Multiboot information structure
struct multiboot_info {
    uint32_t flags;
    uint32_t mem_lower;
    uint32_t mem_upper;
    uint32_t boot_device;
    uint32_t cmdline;
    uint32_t mods_count;
    uint32_t mods_addr;
    uint32_t syms[4];
    uint32_t mmap_length;
    uint32_t mmap_addr;
    uint32_t drives_length;
    uint32_t drives_addr;
    uint32_t config_table;
    uint32_t boot_loader_name;
    uint32_t apm_table;
    uint32_t vbe_control_info;
    uint32_t vbe_mode_info;
    uint16_t vbe_mode;
    uint16_t vbe_interface_seg;
    uint16_t vbe_interface_off;
    uint16_t vbe_interface_len;
};

// =====================================================
// VGA DRIVER
// =====================================================

class VGADriver {
private:
    size_t terminal_row;
    size_t terminal_column;
    uint8_t terminal_color;
    uint16_t* terminal_buffer;

public:
    VGADriver() : terminal_row(0), terminal_column(0), 
                  terminal_color(vga_entry_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK)),
                  terminal_buffer(VGA_MEMORY) {}

    static uint8_t vga_entry_color(enum vga_color fg, enum vga_color bg) {
        return fg | bg << 4;
    }

    static uint16_t vga_entry(unsigned char uc, uint8_t color) {
        return (uint16_t) uc | (uint16_t) color << 8;
    }

    void initialize() {
        terminal_row = 0;
        terminal_column = 0;
        terminal_color = vga_entry_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
        terminal_buffer = VGA_MEMORY;
        
        for (size_t y = 0; y < VGA_HEIGHT; y++) {
            for (size_t x = 0; x < VGA_WIDTH; x++) {
                const size_t index = y * VGA_WIDTH + x;
                terminal_buffer[index] = vga_entry(' ', terminal_color);
            }
        }
    }

    void set_color(uint8_t color) {
        terminal_color = color;
    }

    void put_entry_at(char c, uint8_t color, size_t x, size_t y) {
        const size_t index = y * VGA_WIDTH + x;
        terminal_buffer[index] = vga_entry(c, color);
    }

    void put_char(char c) {
        if (c == '\n') {
            terminal_column = 0;
            if (++terminal_row == VGA_HEIGHT) {
                scroll_up();
                terminal_row = VGA_HEIGHT - 1;
            }
            return;
        }
        
        put_entry_at(c, terminal_color, terminal_column, terminal_row);
        
        if (++terminal_column == VGA_WIDTH) {
            terminal_column = 0;
            if (++terminal_row == VGA_HEIGHT) {
                scroll_up();
                terminal_row = VGA_HEIGHT - 1;
            }
        }
    }

    void write(const char* data, size_t size) {
        for (size_t i = 0; i < size; i++)
            put_char(data[i]);
    }

    void write_string(const char* data) {
        size_t len = strlen(data);
        write(data, len);
    }

    void scroll_up() {
        // Move all lines up by one
        for (size_t y = 1; y < VGA_HEIGHT; y++) {
            for (size_t x = 0; x < VGA_WIDTH; x++) {
                const size_t src_index = y * VGA_WIDTH + x;
                const size_t dst_index = (y - 1) * VGA_WIDTH + x;
                terminal_buffer[dst_index] = terminal_buffer[src_index];
            }
        }
        
        // Clear the last line
        for (size_t x = 0; x < VGA_WIDTH; x++) {
            const size_t index = (VGA_HEIGHT - 1) * VGA_WIDTH + x;
            terminal_buffer[index] = vga_entry(' ', terminal_color);
        }
    }

    void clear_screen() {
        initialize();
    }

private:
    size_t strlen(const char* str) {
        size_t len = 0;
        while (str[len])
            len++;
        return len;
    }
};

// =====================================================
// MEMORY MANAGEMENT
// =====================================================

class MemoryManager {
private:
    uint32_t* memory_bitmap;
    uint32_t total_memory;
    uint32_t used_memory;
    uint32_t free_memory;

public:
    void initialize(multiboot_info* mboot_info) {
        // Calculate total memory from multiboot info
        total_memory = (mboot_info->mem_lower + mboot_info->mem_upper) * 1024;
        used_memory = 0;
        free_memory = total_memory;
        
        // For now, use a simple allocation scheme
        // In a real OS, you'd implement proper paging and heap management
    }

    void* kmalloc(size_t size) {
        // Simple kernel malloc implementation
        // In a real OS, this would use proper heap management
        static uint32_t heap_ptr = 0x400000; // Start at 4MB
        
        void* ptr = (void*)heap_ptr;
        heap_ptr += size;
        used_memory += size;
        free_memory -= size;
        
        return ptr;
    }

    void kfree(void* ptr) {
        // Simple free implementation
        // In a real OS, this would properly manage freed memory
        (void)ptr; // Suppress unused parameter warning
    }

    uint32_t get_total_memory() const { return total_memory; }
    uint32_t get_used_memory() const { return used_memory; }
    uint32_t get_free_memory() const { return free_memory; }
};

// =====================================================
// PROCESS MANAGEMENT
// =====================================================

enum ProcessState {
    PROCESS_READY,
    PROCESS_RUNNING,
    PROCESS_BLOCKED,
    PROCESS_TERMINATED
};

struct Process {
    uint32_t pid;
    ProcessState state;
    uint32_t esp, ebp, eip;
    uint32_t page_directory;
    Process* next;
    char name[32];
};

class ProcessManager {
private:
    Process* process_list;
    Process* current_process;
    uint32_t next_pid;

public:
    ProcessManager() : process_list(nullptr), current_process(nullptr), next_pid(1) {}

    void initialize() {
        // Create init process
        Process* init_proc = create_process("init", (uint32_t)init_process);
        current_process = init_proc;
    }

    Process* create_process(const char* name, uint32_t entry_point) {
        Process* proc = new Process();
        proc->pid = next_pid++;
        proc->state = PROCESS_READY;
        proc->eip = entry_point;
        proc->esp = 0x200000; // 2MB stack
        proc->ebp = proc->esp;
        proc->page_directory = 0; // Use kernel page directory for now
        proc->next = process_list;
        process_list = proc;
        
        // Copy process name
        for (int i = 0; i < 31 && name[i]; i++) {
            proc->name[i] = name[i];
        }
        proc->name[31] = '\0';
        
        return proc;
    }

    void schedule() {
        // Simple round-robin scheduler
        if (!current_process || !current_process->next) {
            current_process = process_list;
        } else {
            current_process = current_process->next;
        }
        
        if (current_process) {
            current_process->state = PROCESS_RUNNING;
        }
    }

    Process* get_current_process() { return current_process; }
    uint32_t get_process_count() {
        uint32_t count = 0;
        Process* proc = process_list;
        while (proc) {
            count++;
            proc = proc->next;
        }
        return count;
    }

private:
    static void init_process() {
        // Init process - just loop forever
        while (true) {
            asm volatile("hlt");
        }
    }
};

// =====================================================
// SYSTEM CALLS
// =====================================================

enum SystemCall {
    SYS_EXIT = 1,
    SYS_FORK = 2,
    SYS_READ = 3,
    SYS_WRITE = 4,
    SYS_OPEN = 5,
    SYS_CLOSE = 6,
    SYS_GETPID = 20,
    SYS_MALLOC = 45,
    SYS_FREE = 46
};

class SystemCallHandler {
private:
    VGADriver* vga;
    MemoryManager* memory;
    ProcessManager* process_mgr;

public:
    SystemCallHandler(VGADriver* v, MemoryManager* m, ProcessManager* p) 
        : vga(v), memory(m), process_mgr(p) {}

    uint32_t handle_syscall(uint32_t syscall_num, uint32_t arg1, 
                           uint32_t arg2, uint32_t arg3, uint32_t arg4) {
        switch (syscall_num) {
            case SYS_WRITE:
                return sys_write(arg1, (char*)arg2, arg3);
            case SYS_READ:
                return sys_read(arg1, (char*)arg2, arg3);
            case SYS_GETPID:
                return process_mgr->get_current_process()->pid;
            case SYS_MALLOC:
                return (uint32_t)memory->kmalloc(arg1);
            case SYS_FREE:
                memory->kfree((void*)arg1);
                return 0;
            case SYS_EXIT:
                // For now, just halt
                asm volatile("cli; hlt");
                return 0;
            default:
                return -1; // Invalid syscall
        }
    }

private:
    uint32_t sys_write(uint32_t fd, char* buffer, uint32_t count) {
        if (fd == 1 || fd == 2) { // stdout or stderr
            for (uint32_t i = 0; i < count; i++) {
                vga->put_char(buffer[i]);
            }
            return count;
        }
        return -1;
    }

    uint32_t sys_read(uint32_t fd, char* buffer, uint32_t count) {
        // For now, just return 0 (EOF)
        (void)fd; (void)buffer; (void)count;
        return 0;
    }
};

// =====================================================
// SHELL
// =====================================================

class Shell {
private:
    VGADriver* vga;
    MemoryManager* memory;
    ProcessManager* process_mgr;
    char command_buffer[256];
    size_t command_pos;

public:
    Shell(VGADriver* v, MemoryManager* m, ProcessManager* p) 
        : vga(v), memory(m), process_mgr(p), command_pos(0) {}

    void run() {
        vga->write_string("\nLlewOS Shell - Made By Llewxam\n");
        vga->write_string("Type 'help' for available commands\n\n");
        
        while (true) {
            show_prompt();
            read_command();
            execute_command();
        }
    }

private:
    void show_prompt() {
        vga->set_color(VGADriver::vga_entry_color(VGA_COLOR_LIGHT_GREEN, VGA_COLOR_BLACK));
        vga->write_string("llewos");
        vga->set_color(VGADriver::vga_entry_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK));
        vga->write_string("$ ");
    }

    void read_command() {
        command_pos = 0;
        
        // Simple command reading (no actual keyboard input in this demo)
        // In a real OS, this would read from keyboard driver
        const char* demo_commands[] = {
            "help", "clear", "meminfo", "ps", "uname", "exit"
        };
        static int cmd_index = 0;
        
        const char* cmd = demo_commands[cmd_index % 6];
        cmd_index++;
        
        // Copy command to buffer
        for (int i = 0; cmd[i] && i < 255; i++) {
            command_buffer[i] = cmd[i];
            command_pos++;
        }
        command_buffer[command_pos] = '\0';
        
        // Display the command
        vga->write_string(command_buffer);
        vga->write_string("\n");
    }

    void execute_command() {
        if (strcmp(command_buffer, "help") == 0) {
            show_help();
        } else if (strcmp(command_buffer, "clear") == 0) {
            vga->clear_screen();
        } else if (strcmp(command_buffer, "meminfo") == 0) {
            show_memory_info();
        } else if (strcmp(command_buffer, "ps") == 0) {
            show_processes();
        } else if (strcmp(command_buffer, "uname") == 0) {
            show_system_info();
        } else if (strcmp(command_buffer, "exit") == 0) {
            vga->write_string("Shutting down LlewOS...\n");
            asm volatile("cli; hlt");
        } else if (command_pos > 0) {
            vga->write_string("Unknown command: ");
            vga->write_string(command_buffer);
            vga->write_string("\n");
        }
    }

    void show_help() {
        vga->write_string("LlewOS Commands - Made By Llewxam:\n");
        vga->write_string("  help     - Show this help message\n");
        vga->write_string("  clear    - Clear the screen\n");
        vga->write_string("  meminfo  - Show memory information\n");
        vga->write_string("  ps       - Show running processes\n");
        vga->write_string("  uname    - Show system information\n");
        vga->write_string("  exit     - Shutdown the system\n");
    }

    void show_memory_info() {
        vga->write_string("Memory Information:\n");
        vga->write_string("  Total: ");
        print_number(memory->get_total_memory() / 1024);
        vga->write_string(" KB\n");
        vga->write_string("  Used:  ");
        print_number(memory->get_used_memory() / 1024);
        vga->write_string(" KB\n");
        vga->write_string("  Free:  ");
        print_number(memory->get_free_memory() / 1024);
        vga->write_string(" KB\n");
    }

    void show_processes() {
        vga->write_string("Running Processes:\n");
        vga->write_string("  PID  NAME\n");
        vga->write_string("  ---  ----\n");
        
        Process* current = process_mgr->get_current_process();
        if (current) {
            vga->write_string("  ");
            print_number(current->pid);
            vga->write_string("    ");
            vga->write_string(current->name);
            vga->write_string("\n");
        }
        
        vga->write_string("\nTotal processes: ");
        print_number(process_mgr->get_process_count());
        vga->write_string("\n");
    }

    void show_system_info() {
        vga->write_string("LlewOS 1.0 - Made By Llewxam\n");
        vga->write_string("Architecture: x86\n");
        vga->write_string("Kernel: Monolithic\n");
        vga->write_string("Build: Development\n");
    }

    void print_number(uint32_t num) {
        if (num == 0) {
            vga->put_char('0');
            return;
        }
        
        char buffer[12];
        int pos = 0;
        
        while (num > 0) {
            buffer[pos++] = '0' + (num % 10);
            num /= 10;
        }
        
        for (int i = pos - 1; i >= 0; i--) {
            vga->put_char(buffer[i]);
        }
    }

    int strcmp(const char* str1, const char* str2) {
        while (*str1 && (*str1 == *str2)) {
            str1++;
            str2++;
        }
        return *str1 - *str2;
    }
};

// =====================================================
// GLOBAL INSTANCES
// =====================================================

VGADriver vga_driver;
MemoryManager memory_manager;
ProcessManager process_manager;
SystemCallHandler syscall_handler(&vga_driver, &memory_manager, &process_manager);
Shell shell(&vga_driver, &memory_manager, &process_manager);

// =====================================================
// KERNEL MAIN FUNCTION
// =====================================================

extern "C" void kernel_main(uint32_t magic, uint32_t addr) {
    // Made By Llewxam - LlewOS Kernel Entry Point
    
    // Initialize VGA driver
    vga_driver.initialize();
    
    // Display kernel banner
    vga_driver.set_color(VGADriver::vga_entry_color(VGA_COLOR_LIGHT_CYAN, VGA_COLOR_BLACK));
    vga_driver.write_string("LlewOS Kernel - Made By Llewxam\n");
    vga_driver.write_string("================================\n\n");
    vga_driver.set_color(VGADriver::vga_entry_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK));
    
    // Verify multiboot magic number
    if (magic != 0x2BADB002) {
        vga_driver.set_color(VGADriver::vga_entry_color(VGA_COLOR_LIGHT_RED, VGA_COLOR_BLACK));
        vga_driver.write_string("ERROR: Invalid multiboot magic number!\n");
        vga_driver.write_string("Expected: 0x2BADB002, Got: 0x");
        // In a real OS, you'd print the hex value here
        vga_driver.write_string("\n");
        return;
    }
    
    vga_driver.write_string("✓ Multiboot verification passed\n");
    
    // Initialize memory management
    multiboot_info* mboot_info = (multiboot_info*)addr;
    memory_manager.initialize(mboot_info);
    vga_driver.write_string("✓ Memory manager initialized\n");
    
    // Initialize process management
    process_manager.initialize();
    vga_driver.write_string("✓ Process manager initialized\n");
    
    // Display system information
    vga_driver.write_string("✓ System calls ready\n");
    vga_driver.write_string("✓ VGA driver active\n");
    
    vga_driver.write_string("\nSystem Information:\n");
    vga_driver.write_string("  Kernel: LlewOS 1.0\n");
    vga_driver.write_string("  Author: Llewxam\n");
    vga_driver.write_string("  Architecture: x86\n");
    vga_driver.write_string("  Memory: ");
    
    // Simple number printing for memory size
    uint32_t total_mem_kb = memory_manager.get_total_memory() / 1024;
    if (total_mem_kb > 1024) {
        vga_driver.write_string("~");
        // Print approximate MB
        char mb_str[8];
        uint32_t mb = total_mem_kb / 1024;
        int pos = 0;
        if (mb == 0) mb_str[pos++] = '0';
        else {
            uint32_t temp = mb;
            while (temp > 0) {
                mb_str[pos++] = '0' + (temp % 10);
                temp /= 10;
            }
            // Reverse the string
            for (int i = 0; i < pos / 2; i++) {
                char temp = mb_str[i];
                mb_str[i] = mb_str[pos - 1 - i];
                mb_str[pos - 1 - i] = temp;
            }
        }
        mb_str[pos] = '\0';
        vga_driver.write_string(mb_str);
        vga_driver.write_string(" MB\n");
    } else {
        vga_driver.write_string("< 1 MB\n");
    }
    
    vga_driver.write_string("\nKernel initialization complete!\n");
    vga_driver.write_string("Starting shell...\n");
    
    // Start the shell
    shell.run();
    
    // Should never reach here
    vga_driver.write_string("\nKernel exiting...\n");
    while (true) {
        asm volatile("hlt");
    }
}

// Made By Llewxam - LlewOS Kernel Complete

